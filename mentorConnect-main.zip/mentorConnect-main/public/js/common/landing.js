document.getElementById("get-started").addEventListener("click", () => {
   // alert("Get Started button clicked! Redirecting to signup...");
    window.location.href = "/auth/register";
  });
  